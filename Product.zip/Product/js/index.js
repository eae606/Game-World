let productElement = document.getElementById("product");
let titleInput = document.getElementById("titleID");
let thirdTitle1 = document.getElementById("thirdTitle1");
let thirdTitle2 = document.getElementById("thirdTitle2");
let thirdTitle3 = document.getElementById("thirdTitle3");
let thirdTitle4 = document.getElementById("thirdTitle4");
let nkarInput = document.getElementById("imageID");
function updateProduct() {
    let productText = titleInput.value + "<br>" +
        thirdTitle1.value + "<br>" +
        thirdTitle2.value + "<br>" +
        thirdTitle3.value + "<br>" +
        thirdTitle4.value;

    document.getElementById("productText").innerHTML = productText;

    let nkarFile = nkarInput.files[0];

    if (nkarFile) {
        let imageUrl = URL.createObjectURL(nkarFile);
        let nkarElement = document.getElementById("productImage");
        nkarElement.src = imageUrl;
        nkarElement.style.display = "block";
    }
}
